function [I_3] = inverse_gl_scramble(I1_1,Y)
[M,N]=size(I1_1);
M1=mod(M,4);
N1=mod(N,4);
M2=M-M1;
N2=N-N1;        %�ܱ�4����������
z1=Y(end-M2*N2+1:end,1);
block1=I1_1(1:M2/2,1:N2/2);
block2=I1_1(1:M2/2,N2/2+1:N2);
block3=I1_1(M2/2+1:M2,1:N2/2);
block4=I1_1(M2/2+1:M2,N2/2+1:N2);

block1_1=block1(:);
block2_1=block2(:);
block3_1=block3(:);
block4_1=block4(:);

[B1 position1]=sort(z1(1:M2*N2/4));
block1_2(position1)=block1_1;
[B2 position2]=sort(z1(M2*N2/4+1:M2*N2/2));
block2_2(position2)=block2_1;
[B3 position3]=sort(z1(M2*N2/2+1:M2*N2/4*3));
block3_2(position3)=block3_1;
[B4 position4]=sort(z1(M2*N2/4*3+1:M2*N2));
block4_2(position4)=block4_1;
for i=1:M2*N2/16
    s1_block1(i)=block1_2(i);
    s1_block2(i)=block1_2(i+M2*N2/16);
    s1_block3(i)=block1_2(i+M2*N2/16*2);
    s1_block4(i)=block1_2(i+M2*N2/16*3);
    
    s2_block1(i)=block2_2(i);
    s2_block2(i)=block2_2(i+M2*N2/16);
    s2_block3(i)=block2_2(i+M2*N2/16*2);
    s2_block4(i)=block2_2(i+M2*N2/16*3);
    
    s3_block1(i)=block3_2(i);
    s3_block2(i)=block3_2(i+M2*N2/16);
    s3_block3(i)=block3_2(i+M2*N2/16*2);
    s3_block4(i)=block3_2(i+M2*N2/16*3);
    
    s4_block1(i)=block4_2(i);
    s4_block2(i)=block4_2(i+M2*N2/16);
    s4_block3(i)=block4_2(i+M2*N2/16*2);
    s4_block4(i)=block4_2(i+M2*N2/16*3);
end

block1_3 = inverse_piecemeal(s1_block1,s2_block1,s3_block1,s4_block1,M2,N2);
block2_3 = inverse_piecemeal(s1_block2,s2_block2,s3_block2,s4_block2,M2,N2);
block3_3 = inverse_piecemeal(s1_block3,s2_block3,s3_block3,s4_block3,M2,N2);
block4_3 = inverse_piecemeal(s1_block4,s2_block4,s3_block4,s4_block4,M2,N2);
I_1=[block1_3,block2_3;block3_3,block4_3];
%����δ���Ҳ���
if M2==M
    I_2=I_1;
else
    I_2=[I_1;I1_1(M2+1:end,1:N2)];
end
if N2==N
    I_3=I_2;
else
    I_3=[I_2,I1_1(:,N2+1:end)];
end
end

