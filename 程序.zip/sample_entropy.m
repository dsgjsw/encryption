clc
clear
close all
u=4;
x=[0.7];
n=1000;
for i=1:n
    x(i+1)=u*x(i)*(1-x(i));
end
SE= SampEn(x, 2,0.2*std(x))