function [I3_1] = inverse_diffuse(I4,Y,a,b,tab1)
% [M N]=size(I4);
% z1=mod(floor((a*Y(end-M*N+1:end,3)+b)*10^14),256);
% z2=mod(floor(Y(end-M*N+1:end,4)*10^14),3);
% z1=reshape(z1,[M,N]);
% z2=reshape(z2,[M,N]);
% [M N]=size(I4);
% for i=1:M
%     for j=1:N
%         if z2(i,j)==0
%             I3_1(i,j)=bitxor(I4(i,j),z1(i,j));
%         end
%         if z2(i,j)==1
%             I3_1(i,j)=I4(i,j)+z1(i,j);
%             if I3_1(i,j)>255
%                 I3_1(i,j)=I3_1(i,j)-256;
%             end
%         end
%         if z2(i,j)==2
%             I3_1(i,j)=I4(i,j)-z1(i,j);
%             if I3_1(i,j)<0
%                 I3_1(i,j)=I3_1(i,j)+256;
%             end
%         end
%     end
% end
%�µ�����ɢ
[M N]=size(I4);
z1=Y(end-M*N+1:end,3);
z2=mod(floor((a*Y(end-M*N+1:end,4)+b)*10^14),256);
% I4_1_1=reshape(I4,[1,M*N]);
I4_2=reshape(I4(1:M/2,1:N/2),[1,M/2*N/2]);
I4_3=reshape(I4(1:M/2,N/2+1:N),[1,M/2*N/2]);
I4_4=reshape(I4(M/2+1:M,1:N/2),[1,M/2*N/2]);
I4_5=reshape(I4(M/2+1:M,N/2+1:N),[1,M/2*N/2]);
I4_1_1=[I4_2,I4_3,I4_4,I4_5];
for i=M*N:-1:2
%     I4_1_2(i)=bitxor(I4_1_1(i),I4_1_1(i-1));
%     I4_1_3(i)=find(tab1(z2(i)+1,:)==I4_1_2(i))-1;
    I4_1_3(i)=find(tab1(z2(i)+1,:)==bitxor(I4_1_1(i),I4_1_1(i-1)))-1;
%     I4_1_3(i)=find(tab1(z2(i)+1,:)==I4_1_1(i))-1;

end
I4_1_3(1)=find(tab1(z2(1)+1,:)==I4_1_1(1))-1;

I4_1_3_1=reshape(I4_1_3(1:end/4),[M/2,N/2]);
I4_1_3_2=reshape(I4_1_3(end/4+1:end/4*2),[M/2,N/2]);
I4_1_3_3=reshape(I4_1_3(end/4*2+1:end/4*3),[M/2,N/2]);
I4_1_3_4=reshape(I4_1_3(end/4*3+1:end/4*4),[M/2,N/2]);
I3_1=[I4_1_3_1,I4_1_3_2;I4_1_3_3,I4_1_3_4];
end

