function [block] = block_matrix(a)
switch a
    case 1
        block4=[37,13,9,1;
                41,33,17,5;
                57,45,29,21;
                61,53,49,25];
        block3=rot90(block4+1,-1);
        block1=rot90(block3+1,-1);
        block2=rot90(block1+1,-1);
        block=[block1,block2;block3,block4;];
    case 2
        block4=[61,57,41,37;
                53,45,33,13;
                49,29,17,9;
                25,21,5,1];
        block3=rot90(block4+1,-1);
        block1=rot90(block3+1,-1);
        block2=rot90(block1+1,-1);
        block=[block1,block2;block3,block4;];
    case 3
        block4=[25,49,53,61;
                21,29,45,57;
                5,17,33,41;
                1,9,13,37];
        block3=rot90(block4+1,-1);
        block1=rot90(block3+1,-1);
        block2=rot90(block1+1,-1);
        block=[block1,block2;block3,block4;];
    case 4
        block3=[61,57,41,37;
                53,45,33,13;
                49,29,17,9;
                25,21,5,1];
        block1=rot90(block3+1,-1);
        block2=rot90(block1+1,-1);
        block4=rot90(block2+1,-1);
        block=[block1,block2;block3,block4;];
    case 5
        block3=[25,49,53,61;
                21,29,45,57;
                5,17,33,41;
                1,9,13,37];
        block1=rot90(block3+1,-1);
        block2=rot90(block1+1,-1);
        block4=rot90(block2+1,-1);
        block=[block1,block2;block3,block4;];
    case 6
        block3=[1,5,21,25;
                9,17,29,49;
                13,33,45,53;
                37,41,57,61];
        block1=rot90(block3+1,-1);
        block2=rot90(block1+1,-1);
        block4=rot90(block2+1,-1);
        block=[block1,block2;block3,block4;];
    case 7
        block1=[25,49,53,61;
                21,29,45,57;
                5,17,33,41;
                1,9,13,37];
        block2=rot90(block1+1,-1);
        block4=rot90(block2+1,-1);
        block3=rot90(block4+1,-1);
        block=[block1,block2;block3,block4;];
    case 8
        block1=[1,5,21,25;
                9,17,29,49;
                13,33,45,53;
                37,41,57,61];
        block2=rot90(block1+1,-1);
        block4=rot90(block2+1,-1);
        block3=rot90(block4+1,-1);
        block=[block1,block2;block3,block4;]; 
    case 9
        block1=[37,13,9,1;
                41,33,17,5;
                57,45,29,21;
                61,53,49,25];
        block2=rot90(block1+1,-1);
        block4=rot90(block2+1,-1);
        block3=rot90(block4+1,-1);
        block=[block1,block2;block3,block4;];
    case 10
        block2=[1,5,21,25;
                9,17,29,49;
                13,33,45,53;
                37,41,57,61];
        block4=rot90(block2+1,-1);
        block3=rot90(block4+1,-1);
        block1=rot90(block3+1,-1);
        block=[block1,block2;block3,block4;];
    case 11
        block2=[37,13,9,1;
                41,33,17,5;
                57,45,29,21;
                61,53,49,25];
        block4=rot90(block2+1,-1);
        block3=rot90(block4+1,-1);
        block1=rot90(block3+1,-1);
        block=[block1,block2;block3,block4;];  
    case 12
        block2=[61,57,41,37;
                53,45,33,13;
                49,29,17,9;
                25,21,5,1];
        block4=rot90(block2+1,-1);
        block3=rot90(block4+1,-1);
        block1=rot90(block3+1,-1);
        block=[block1,block2;block3,block4;];         
end
end

