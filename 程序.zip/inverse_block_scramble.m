function [I1_4] = inverse_block_scramble(I2_1,Y)
[M N]=size(I2_1);
z1=mod(floor(Y(end-M*N+1:end,2)*10^10),12);
M1=mod(M,8);
N1=mod(N,8);
M2=M-M1;
N2=N-N1;
for i=1:M2/8
    for j=1:N2/8
       q=I2_1((i-1)*8+1:i*8,(j-1)*8+1:j*8); 
       q=q(:);
       
        sp=block_matrix(z1((i-1)*N2/8+j)+1);
       p1=q(sp);
       I1_1((i-1)*8+1:i*8,(j-1)*8+1:j*8)=p1;
    end
end
%����ʣ�ಿ��
if M2==M
    I1_2=I1_1;
else
    I1_2=[I1_1;I2_1(M2+1:end,1:N2)];
end
if N2==N
    I1_3=I1_2;
else
    I1_3=[I1_2,I2_1(:,N2+1:end)];
end
I1_3=fliplr(I1_3);
I1_4=flipud(I1_3);
end

