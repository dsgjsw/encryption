function Chi = Chi_square(I,M,N)
count=[0];
for i=1:256
    ff=find(I(:)==i-1);
    count(i)=size(ff,1);
end
Chi=sum((count-M*N/256).^2/(M*N/256));
end

