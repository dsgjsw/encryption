function [I4,tab1] = diffuse(I3,Y,a,b)
% [M N]=size(I3);
% z1=mod(floor((a*Y(end-M*N+1:end,3)+b)*10^14),256);
% z2=mod(floor(Y(end-M*N+1:end,4)*10^14),3);
% z1=reshape(z1,[M,N]);
% z2=reshape(z2,[M,N]);
% for i=1:M
%     for j=1:N
%         if z2(i,j)==0
%             I4(i,j)=bitxor(I3(i,j),z1(i,j));
%         end
%         if z2(i,j)==1
%             I4(i,j)=I3(i,j)-z1(i,j);
%             if I4(i,j)<0
%                 I4(i,j)=I4(i,j)+256;
%             end
%         end
%         if z2(i,j)==2
%             I4(i,j)=I3(i,j)+z1(i,j);
%             if I4(i,j)>255
%                 I4(i,j)=I4(i,j)-256;
%             end
%         end
%     end
% end

%�µ���ɢ
I2=I3;
[M N]=size(I3);
z1=Y(end-M*N+1:end,3);
z2=mod(floor((a*Y(end-M*N+1:end,4)+b)*10^14),256);
tab=zeros(256,256);
%������ɢ��
%��ʼ����ɢ��
for i=1:256
    for j=1:256
        tab(i,j)=j-1;
    end
end
%�γ���ɢ��
for i=1:256
    [B(i,:) position(i,:)]=sort(z1((i-1)*256+1:i*256));
    m=position(i,:);
    n=tab(i,:);
    tab1(i,:)=n(m);
end
I2_1=I2(1:M/2,1:N/2);
I2_2=I2(1:M/2,N/2+1:end);
I2_3=I2(M/2+1:end,1:N/2);
I2_4=I2(M/2+1:end,N/2+1:end);
I2_1_1=reshape(I2_1,[1,M/2*N/2]);
I2_2_1=reshape(I2_2,[1,M/2*N/2]);
I2_3_1=reshape(I2_3,[1,M/2*N/2]);
I2_4_1=reshape(I2_4,[1,M/2*N/2]);
I2_length=[I2_1_1,I2_2_1,I2_3_1,I2_4_1];
I4_1(1)=tab1(z2(1)+1,I2_length(1)+1);
%  I4_2(1)=I4_1(1);
for i=2:M*N

     I4_1(i)=bitxor(tab1(z2(i)+1,I2_length(i)+1),I4_1(i-1));
end
I4_2=reshape(I4_1(1:M*N/4),[M/2,N/2]);
I4_3=reshape(I4_1(M*N/4+1:M*N/2),[M/2,N/2]);
I4_4=reshape(I4_1(M*N/2+1:M*N/4*3),[M/2,N/2]);
I4_5=reshape(I4_1(M*N/4*3+1:M*N),[M/2,N/2]);
I4=[I4_2,I4_3;I4_4,I4_5];
end

