function [I3_2,d] = semi_tensor(I2,Y)
[M,N]=size(I2);
z1=mod(floor(Y(end-M*N+1:end,3)*10^10),256);
t1=mod(floor(z1(1)*10^10),3)+3;
t2=t1;
for i=1:2^t1*2^t2
    A(i)=z1(i+1);
end
A1=reshape(A,[2^t2,2^t1]);
M1=mod(M,2^t2);
M2=M-M1;
m=2^t1;
n=M2;
z=n/m;
I3=floor(kron(A1,eye(z))*I2(1:M2,:));

%����ʣ�ಿ��
if M2==M
    I3_1=I3;
else
    I3_1=[I3;I2(M2+1:end,:)];
end
I3_2=mod(I3_1,256);
d=floor(I3_1/256);
end

