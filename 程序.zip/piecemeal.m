function [s1_block1,s2_block1,s3_block1,s4_block1] = piecemeal(block1,M2,N2)
block1_1=block1(:);
for j=1:N2/4
    for i=1:M2/4
        s1_block1(M2/4*(j-1)+i)=block1_1(M2*(j-1)+2*(i-1)+1);
        s2_block1(M2/4*(j-1)+i)=block1_1(M2*(j-1)+2*i);
        s3_block1(M2/4*(j-1)+i)=block1_1(M2*(j-1)+M2/2+2*(i-1)+1);
        s4_block1(M2/4*(j-1)+i)=block1_1(M2*(j-1)+M2/2+2*i);
    end
end
end

