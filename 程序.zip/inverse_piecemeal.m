function [block1_1] = inverse_piecemeal(s1_block1,s2_block1,s3_block1,s4_block1,M2,N2)
for j=1:N2/4
    for i=1:M2/4
        block1_1(M2*(j-1)+2*(i-1)+1)=s1_block1(M2/4*(j-1)+i);
        block1_1(M2*(j-1)+2*i)=s2_block1(M2/4*(j-1)+i);
        block1_1(M2*(j-1)+M2/2+2*(i-1)+1)=s3_block1(M2/4*(j-1)+i);
        block1_1(M2*(j-1)+M2/2+2*i)=s4_block1(M2/4*(j-1)+i);
    end
end
block1_1=reshape(block1_1,[M2/2,N2/2]);
end

