function [I2_3] = inverse_semi_tensor(I3_1,d,Y,M,N)
I2_1=d*256+I3_1;
z1=mod(floor(Y(end-M*N+1:end,3)*10^10),256);
t1=mod(floor(z1(1)*10^10),3)+3;
t2=t1;
for i=1:2^t1*2^t2
    A(i)=z1(i+1);
end
A1=reshape(A,[2^t2,2^t1]);
M1=mod(M,2^t2);
M2=M-M1;
m=2^t1;
n=M2;
z=n/m;
I2_2=floor(inv(kron(A1,eye(z)))*I2_1(1:M2,:));
%����ʣ�ಿ��
if M2==M
    I2_3=I2_2;
else
    I2_3=[I2_2;I2_1(M2+1:end,:)];
end
end

