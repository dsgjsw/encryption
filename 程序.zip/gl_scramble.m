function [I1_2] = gl_scramble(I,Y)
[M,N]=size(I);
M1=mod(M,4);
N1=mod(N,4);
M2=M-M1;
N2=N-N1;        %�ܱ�4����������
z1=Y(end-M2*N2+1:end,1);
block1=I(1:M2/2,1:N2/2);
block2=I(1:M2/2,N2/2+1:N2);
block3=I(M2/2+1:M2,1:N2/2);
block4=I(M2/2+1:M2,N2/2+1:N2);
%�ֿ飬��ÿ��С��ֳ��ĸ�����
[s1_block1,s2_block1,s3_block1,s4_block1] = piecemeal(block1,M2,N2);
[s1_block2,s2_block2,s3_block2,s4_block2] = piecemeal(block2,M2,N2);
[s1_block3,s2_block3,s3_block3,s4_block3] = piecemeal(block3,M2,N2);
[s1_block4,s2_block4,s3_block4,s4_block4] = piecemeal(block4,M2,N2);
block1_1=[s1_block1,s1_block2,s1_block3,s1_block4];
block2_1=[s2_block1,s2_block2,s2_block3,s2_block4];
block3_1=[s3_block1,s3_block2,s3_block3,s3_block4];
block4_1=[s4_block1,s4_block2,s4_block3,s4_block4];
%��ÿ��С����ĸ����ֽ�������
[B1 position1]=sort(z1(1:M2*N2/4));
block1_2=block1_1(position1);
[B2 position2]=sort(z1(M2*N2/4+1:M2*N2/2));
block2_2=block2_1(position2);
[B3 position3]=sort(z1(M2*N2/2+1:M2*N2/4*3));
block3_2=block3_1(position3);
[B4 position4]=sort(z1(M2*N2/4*3+1:M2*N2));
block4_2=block4_1(position4);

block1_3=reshape(block1_2,[M2/2,N2/2]);
block2_3=reshape(block2_2,[M2/2,N2/2]);
block3_3=reshape(block3_2,[M2/2,N2/2]);
block4_3=reshape(block4_2,[M2/2,N2/2]);
%�ϳ�һ��
I1=[block1_3,block2_3;block3_3,block4_3];
%����δ���Ҳ���
if M2==M
    I1_1=I1;
else
    I1_1=[I1;I(M2+1:end,1:N2)];
end
if N2==N
    I1_2=I1_1;
else
    I1_2=[I1_1,I(:,N2+1:end)];
end
end

