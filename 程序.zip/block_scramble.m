function [I2_3] = block_scramble(I1_2,Y)
[M N]=size(I1_2);

z1=mod(floor(Y(end-M*N+1:end,2)*10^10),12);
I2_1=flipud(I1_2);
I2_1=fliplr(I2_1);
M1=mod(M,8);
N1=mod(N,8);
M2=M-M1;
N2=N-N1;
I2=zeros(M2,N2);
for i=1:M2/8
    for j=1:N2/8
        sp=block_matrix(z1((i-1)*N2/8+j)+1);
        p1=I2_1((i-1)*8+1:i*8,(j-1)*8+1:j*8);    
        q(sp)=p1;
        q=reshape(q,[8 8]);
        I2((i-1)*8+1:i*8,(j-1)*8+1:j*8)=q;        
    end
end
%����ʣ�ಿ��
if M2==M
    I2_2=I2;
else
    I2_2=[I2;I1_2(M2+1:end,1:N2)];
end
if N2==N
    I2_3=I2_2;
else
    I2_3=[I2_2,I1_2(:,N2+1:end)];
end
end

