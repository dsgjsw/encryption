function [x,p,k] = initial_value(I)
[M,N]=size(I);
average=mean(mean(I));
sd=std2(I);
row=zeros(1,N);
for i=1:M
    row=bitxor(I(i,:),row);
end
num_bitxor=floor(N/4);
col=zeros(4,1);
for i=1:4
    for j=1:num_bitxor
        col(i,j+1)=bitxor(col(i,j),row((i-1)*num_bitxor+j));
    end
end
k=col(:,end);
% x(1)=1+(k(1)+average+row(end))/256+sd*10^-6;
x(1)=0.7+(k(1)+average+row(end))/256/3+sd*10^-6;
x(2)=0.7+(k(2)+average+row(end-1))/256/3+sd*10^-6;
x(3)=0.7;                                                                                                                                    
x(4)=0.7;
p(1)=6+(k(3)+average+row(end-4))/256/3+sd*10^-6;
p(2)=4+(k(4)+average+row(end-5))/256/3+sd*10^-6;
p(3)=4;
p(4)=6;

end

